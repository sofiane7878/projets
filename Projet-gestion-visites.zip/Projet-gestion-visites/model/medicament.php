<?php

class Medicament{
    private $idMedi;
    private $nomComMedi;
    private $idFamilleMedi;
    private $compoMedi;
    private $effetsMedi;
    private $contreIndicMedi;

    public function __construct($idMedi,$nomComMedi,$idFamilleMedi,$compoMedi,$effetsMedi,$contreIndicMedi){
        $this->idMedi=(int)$idMedi;
        $this->nomComMedi=(string)$nomComMedi;
        $this->idFamilleMedi=(int)$idFamilleMedi;
        $this->compoMedi=(string)$compoMedi;
        $this->effetsMedi=(string)$effetsMedi;
        $this->contreIndicMedi=(string)$contreIndicMedi;
    }

    public function addMedicament($nouveauMedicament, $pdo){
        $sql = "INSERT INTO medicament (id, nomCommercial, composition, idFamille, effets, contreindications) 
                VALUES (0,'{$nouveauMedicament->nomComMedi}', '{$nouveauMedicament->compoMedi}',
                 '{$nouveauMedicament->idFamilleMedi}', '{$nouveauMedicament->effetsMedi}', 
                 '{$nouveauMedicament->contreIndicMedi}')";
    
        $pdo->query($sql);
    }
    

}

?>