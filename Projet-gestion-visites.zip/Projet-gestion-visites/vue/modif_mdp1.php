<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        a {
            text-align: center;
            color: #333;
            text-decoration: none;
            display: block;
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <h1>Première connexion. <br>Entrez un nouveau mot de passe:</h1><br></br>
    <h2> Attention ! Vos mots de passe doivent être identiques.</h2>

    <form action="../controller/passerelle_modif_mdp.php" method="POST">
        <div>
            <label for="mdp">Nouveau mot de passe:</label>
            <input type="password" name="mdp" id="mdp" />
            <label for="text">Le mot de passe à au moins 8 caractères, un chiffre, une lettre minuscule, majuscule et un caractère spécial.</label>

        </div>

        <div>
            <label for="mdp1">Vérifier le mot de passe:</label>
            <input type="password" name="mdp1" id="mdp1" />
            <label for="text">Le mot de passe à au moins 8 caractères, un chiffre, une lettre minuscule, majuscule et un caractère spécial.</label>

        </div>

        <div>
            <input type="submit" value="Entrer" />
        </div>
    </form>


</body>

</html>

