<?php
$pdo = new PDO("mysql:host=localhost;dbname=gestionvisite",'root','');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

//SESSION
session_start();

//CHEMIN
define('RACINE_SITE','/ensitech/projet_ap2/');

?>